library(shiny)
ui = shinyUI(fluidPage(
  titlePanel(h2("Correlation between Hit and Run Scored", align="center")),
  sidebarLayout(
    sidebarPanel(
      selectInput("var1", "select X variable", choices=c("H"=1, "R"=2, "ERA"=3)),
      selectInput("var2", "select Y variable", choices=c("H"=1, "R"=2, "ERA"=3))
    ),
    mainPanel(h4("The correlation coefficient between the two variables is"),
              textOutput("correlation"), br(),
              h4("Scatterplot between the two variables"),
              plotOutput("plot"))
  )
))