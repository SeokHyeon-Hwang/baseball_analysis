library(shiny)
library(Lahman)
dat<-subset(Teams, yearID==2016, select=c(H, R, ERA))
server = shinyServer(
  function(input, output)({
    x <- reactive({dat[, as.numeric(input$var1)]})
    y <- reactive({dat[, as.numeric(input$var2)]})
    output$correlation <- renderPrint({cor(x(), y())})
    output$plot <- renderPlot(({plot(x(), y())}))
  })
)